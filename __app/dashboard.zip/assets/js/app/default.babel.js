(function () {
	const app = {
		windowHeight: window.innerHeight,
		windowWidth: window.innerWidth,
		isMobile: false,
		isTouch: false,
		resizeTimeoutID: null,
		culture: 'en',
		isIe: false,
		responsiveBreakpointValue: '(max-width: 1200px)',
		responsiveBreakpointBoolean: false,
		hamburgerBoolean: false,
		hamburgerBoolean2: false,
		successSwiper: false,
		tabSwiper: null,
		disableAnimation: false,
		lifestyleSwiper: null,
		markersArray: [],
		tabsList: document.querySelector(".tabs-list"),

		detectDevice() {
			const ua = navigator.userAgent || navigator.vendor || window.opera;
			const mobileRegex = /android|iphone|ipad|ipod|blackberry|windows phone/i;
			app.isMobile = mobileRegex.test(ua);

			if (app.isMobile) {
				app.isTouch = true;
				document.body.classList.add('touch');
			} else {
				document.body.classList.add('no-touch');
			}
		},

		detectCulture() {
			if (document.body.classList.contains('ar')) {
				app.culture = 'ar';
			}
		},

		windowResize() {
			app.windowHeight = window.innerHeight;
			app.windowWidth = window.innerWidth;
			const spacer = document.querySelector('.swiper-spacer');
			if (!spacer) return;
			document.querySelectorAll('.spotlight__slide.swiper-slide').forEach(el => {
				el.style.height = `${spacer.offsetHeight}px`;
			});
		},

		resizeListener() {
			if (!app.isMobile) {
				window.addEventListener('resize', () => {
					clearTimeout(app.resizeTimeoutID);
					app.resizeTimeoutID = setTimeout(app.windowResize, 500);
				});
			} else {
				window.addEventListener('orientationchange', app.windowResize);
			}
		},

		addEventListeners() {
			// Implement addEventListeners() conversions here as needed
		},

		login() {
			const loginForm = document.getElementById('loginForm');
			const errorMessage = document.getElementById('errorMessage');

			if (!loginForm) return;

			loginForm.addEventListener('submit', function (e) {
				e.preventDefault();

				const username = document.getElementById('username').value;
				const password = document.getElementById('password').value;

				if (username === 'admin' && password === 'qwerty') {
					localStorage.setItem('isLoggedIn', 'true');
					window.location.href = 'dashboard-admin.html';
				} else if (username === 'user' && password === 'qwerty') {
					localStorage.setItem('isLoggedIn', 'true');
					window.location.href = 'dashboard-user.html';
				} else {
					errorMessage.textContent = 'Invalid username or password';
					errorMessage.classList.remove('hidden');
				}
			});
		},

		dashboard() {


			// Check authentication
			if (localStorage.getItem('isLoggedIn') !== 'true') {
				window.location.href = 'index.html';
			}

			const logoutBtn = document.getElementById('logoutBtn');
			if (logoutBtn) {
				// Logout functionality
				logoutBtn.addEventListener('click', function () {
					localStorage.removeItem('isLoggedIn');
					window.location.href = 'index.html';
				});
			};



			// Initialize charts
			const salesCtx = document.getElementById('salesChart').getContext('2d');
			const salesChart = new Chart(salesCtx, {
				type: 'bar',
				data: {
					labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
					datasets: [{
						label: 'Sales 2023',
						data: [12, 19, 3, 5, 2, 3],
						backgroundColor: '#3B82F6',
						borderColor: '#1D4ED8',
						borderWidth: 1
					}]
				},
				options: {
					responsive: true,
					maintainAspectRatio: false,
					scales: {
						y: {
							beginAtZero: true
						}
					}
				}
			});

			const trafficCtx = document.getElementById('trafficChart').getContext('2d');
			const trafficChart = new Chart(trafficCtx, {
				type: 'doughnut',
				data: {
					labels: ['Direct', 'Social', 'Email', 'Referral'],
					datasets: [{
						data: [300, 150, 100, 200],
						backgroundColor: [
							'#EF4444',
							'#3B82F6',
							'#F59E0B',
							'#10B981'
						],
						borderWidth: 1
					}]
				},
				options: {
					responsive: true,
					maintainAspectRatio: false,
					plugins: {
						legend: {
							position: 'bottom'
						}
					}
				}
			});

		},

		userDropDown() {
			const adminMenuButton = document.getElementById('admin-menu-button');
			const adminDropdownMenu = document.getElementById('admin-dropdown-menu');
			const adminLogout = document.getElementById('admin-logout');

			if (adminMenuButton) {
				adminMenuButton.addEventListener('click', () => {
					const isExpanded = adminMenuButton.getAttribute('aria-expanded') === 'true';
					adminMenuButton.setAttribute('aria-expanded', !isExpanded);
					adminDropdownMenu.classList.toggle('hidden');
				});

				// Close dropdown when clicking outside
				document.addEventListener('click', (e) => {
					if (!adminMenuButton.contains(e.target) && !adminDropdownMenu.contains(e.target)) {
						adminMenuButton.setAttribute('aria-expanded', 'false');
						adminDropdownMenu.classList.add('hidden');
					}
				});

				// Logout functionality
				adminLogout.addEventListener('click', (e) => {
					e.preventDefault();
					localStorage.removeItem('isLoggedIn');
					localStorage.removeItem('isAdmin');
					window.location.href = '/login';
				});
			}

			// User dropdown functionality
			const userMenuButton = document.getElementById('user-menu-button');
			const userDropdownMenu = document.getElementById('user-dropdown-menu');
			const userLogout = document.getElementById('user-logout');

			if (userMenuButton) {
				userMenuButton.addEventListener('click', () => {
					const isExpanded = userMenuButton.getAttribute('aria-expanded') === 'true';
					userMenuButton.setAttribute('aria-expanded', !isExpanded);
					userDropdownMenu.classList.toggle('hidden');
				});

				// Close dropdown when clicking outside
				document.addEventListener('click', (e) => {
					if (!userMenuButton.contains(e.target) && !userDropdownMenu.contains(e.target)) {
						userMenuButton.setAttribute('aria-expanded', 'false');
						userDropdownMenu.classList.add('hidden');
					}
				});

				// Logout functionality
				userLogout.addEventListener('click', (e) => {
					e.preventDefault();
					localStorage.removeItem('isLoggedIn');
					window.location.href = '/login';
				});
			}
		},

		init() {
			app.detectCulture();
			app.detectDevice();
			app.resizeListener();
			app.addEventListeners();
			app.login();
			app.dashboard();
			app.userDropDown();
		}
	};

	window.app = app;
})();

document.addEventListener('DOMContentLoaded', () => {
	window.app.init();
});